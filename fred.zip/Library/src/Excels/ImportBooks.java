/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Excels;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 *
 * @author regis
 */
public class ImportBooks{
    public static void main(String[] args){
        long seconds = System.currentTimeMillis();
        insertValues(importData());
        long second = System.currentTimeMillis();
        System.out.println(second - seconds);
    }
    public static List importData(){
        List<Books> bookList = new ArrayList<>();
        try {
            File f = new File("/home/regis/Documents/Book1.xls");
            Workbook workbook = Workbook.getWorkbook(f);
            Sheet sheet = workbook.getSheet(0);
            for (int i = 1; i < 1000; i++) {
                
                Books b = new Books();
                for (int j = 0; j < 4; j++) {
                    
                    Cell c = sheet.getCell(j,i);
                    switch(j){
                        case 0: b.setId(Integer.parseInt(c.getContents()));break;
                        case 1: b.setName(c.getContents());break;
                        case 2: b.setAuthor(c.getContents());break;
                        case 3: b.setPages(Integer.parseInt(c.getContents()));break;
                        default:break;
                    }
                }
                bookList.add(b);
            }
        } catch (IOException | BiffException ex) {
            Logger.getLogger(ImportBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bookList;
    }
    public static void insertValues(List<Books> list){
        try {
            Connection c;
            PreparedStatement ps ;
            int batchSize = 200;
            int counter = 0;
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Library","postgres","postgres");
            ps = c.prepareStatement("INSERT INTO BOOKS VALUES(?,?,?,?);");
            c.setAutoCommit(false);
            for(Books b: list){
                counter++;
                ps.setInt(1, b.getId());
                ps.setString(2, b.getName());
                ps.setString(3, b.getAuthor());
                ps.setInt(4, b.getPages());
                ps.addBatch();
                if(counter%batchSize==0){
                    ps.executeBatch();
                }
                
            }
            ps.executeBatch();
            c.commit();
            c.setAutoCommit(true);
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(ImportBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 }
        
