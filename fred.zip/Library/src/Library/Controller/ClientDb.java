/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import Library.Model.Client;
import Library.Model.ClientCategory;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author regis
 */
public class ClientDb extends ConnectDatabase{
    public void createTable(){
        try {
            connect();
            s = c.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS Client("
                    +"RegNo varchar(50) PRIMARY KEY NOT NULL,"
                    +"Firstname varchar(50) NOT NULL,"
                    +"LastName varchar(50) NOT NULL,"
                    +"Phone varchar(50) NOT NULL,"
                    +"Email varchar(50) NOT NULL,"
                    +"Photo varchar(150) NOT NULL,"
                    +"Category varchar(50) NOT NULL);";
            s.executeUpdate(sql);
            s.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void insertClient(Client client){
        try {
            createTable();
            connect();
            PreparedStatement ps = c.prepareStatement("INSERT INTO Client VALUES(?,?,?,?,?,?,?)");
            ps.setString(1, client.getRegNo());
            ps.setString(2, client.getFirstName());
            ps.setString(3, client.getLastName());
            ps.setString(4, client.getPhoneNumber());
            ps.setString(5, client.getEmail());
            ps.setString(6, client.getPhoto());
            ps.setString(7, String.valueOf(client.getClientCategory()));
            
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List allClients(){
        List<Client> clients = new ArrayList<>();
        try {
            connect();
            String sql = "SELECT * FROM Client";
            s = c.createStatement();
            rs = s.executeQuery(sql);
            while(rs.next()){
                if(rs.getString(7).equals("Student")){
                    clients.add(new Client(rs.getString(1),
                            rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),ClientCategory.STUDENT));
                }
                else if(rs.getString(7).equals("Staff")){
                    clients.add(new Client(rs.getString(1),
                            rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),ClientCategory.STAFF));
                }
                else{
                    clients.add(new Client(rs.getString(1),
                            rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),ClientCategory.EXTERNAL));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clients;
    }
}
