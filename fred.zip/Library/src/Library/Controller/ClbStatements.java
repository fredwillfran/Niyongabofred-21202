/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author regis
 */
public class ClbStatements extends ConnectDatabase{
    public void createCallable(){
        try {
            CallableStatement cs = c.prepareCall("{call getEmpName(?,?)}");
            cs.setString(0, link);
        } catch (SQLException ex) {
            
        }
    }
}
