/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import Library.Model.CheckInOutC;
import Library.Model.Operation;
import Library.View.CheckInOut;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author regis
 */
public class OperationDb extends ConnectDatabase{
    public void createTableOperation(){
        try {
            connect();
            s = c.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS Operation("
                    +"First_name varchar(50) NOT NULL,"
                    +"Book_name varchar(50) NOT NULL,"
                    +"Date varchar(50) NOT NULL,"
                    +"status varchar(50) NOT NULL);";
            s.executeUpdate(sql);
            s.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
    }
    public void checkInOut(String firstname,String bookName,CheckInOutC cio){
        LocalDateTime now = cio.getDateTime();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String dateNow = now.format(df);
        if(cio.getOperationCategory().toString().equalsIgnoreCase("checkOut")){
            try {
                connect();
                PreparedStatement ps = c.prepareStatement("INSERT INTO Operation VALUES(?,?,?,?);");
                ps.setString(1, firstname);
                ps.setString(2, bookName);
                ps.setString(3, dateNow);
                ps.setString(4, cio.getStatus());
                
                ps.executeUpdate();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                disconnect();
            }
        }
        else if(cio.getOperationCategory().toString().equalsIgnoreCase("checkIn")){
            try {
                connect();
                PreparedStatement ps = c.prepareStatement("UPDATE Operation set status=? WHERE first_name=? AND book_name=?");
                ps.setString(1, cio.getStatus());
                ps.setString(2, firstname);
                ps.setString(3, bookName);
                
                ps.executeUpdate();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                disconnect();
            }
        }
    }
    public List allOperations(){
        List<Operation> operations = new ArrayList<>();
        try {
            connect();
            String sql = "SELECT * From Operation";
            s = c.createStatement();
            rs = s.executeQuery(sql);
            while(rs.next()){
                operations.add(new Operation(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
        return operations;
    }
    public boolean checkBook(String bookname){
        boolean check = false;
        try {
            connect();
            String sql = "SELECT * FROM Operation";
            s = c.createStatement();
            rs = s.executeQuery(sql);
            while(rs.next()){
                if((rs.getString(2).equalsIgnoreCase(bookname))&&(rs.getString(4).equalsIgnoreCase("Not Returned"))){
                    check = true;
                }
                else if((rs.getString(2).equalsIgnoreCase(bookname))&&(rs.getString(4).equalsIgnoreCase("Returned"))){
                    check = false;
                }
            }
        } catch (Exception e) {
        }finally{
            disconnect();
        }
        return check;
    }
}
