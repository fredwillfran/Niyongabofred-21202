/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import Library.Model.Users;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author regis
 */
public class UserDb extends ConnectDatabase{
    public void createTableUser(){
        try {
            connect();
            String sql = "CREATE TABLE IF NOT EXISTS Users("
                    + "name varchar(50) NOT NULL,"
                    + "fullName varchar(50) NOT NULL,"
                    + "password varchar(50) NOT NULL,"
                    + "active varchar(50) NOT NULL);";
            s = c.createStatement();
            s.executeUpdate(sql);
        } catch (SQLException ex) {
            
        }finally{
            disconnect();
        }
    }
    public void insertUser(Users user){
        try {
            createTableUser();
            connect();
            PreparedStatement ps = c.prepareStatement("INSERT INTO Users values(?,?,?,?);");
            ps.setString(1, user.getName());
            ps.setString(2, user.getFullName());
            ps.setString(3, user.getPassword());
            ps.setBoolean(4, true);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
        }finally{
            disconnect();
        }
    }
}
