/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author regis
 */
public class ConnectDatabase {
    
    
    String link = "jdbc:postgresql://localhost:5432/Library";
    
    String username = "postgres";
    
    String password = "postgres";
    
    public Connection c = null;
    
    Statement s = null;
    
    ResultSet rs = null;
    
    public void connect(){
        try {
            c = DriverManager.getConnection(link,username,password);
        } catch (Exception e) {
        }
    }
    
    public void disconnect(){
        try {
            if(s!=null){
                s.close();
            }
            if(c!=null){
                c.close();
            }
            if(rs!=null){
                rs.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
