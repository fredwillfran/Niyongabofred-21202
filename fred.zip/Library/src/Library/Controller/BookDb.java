/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import Library.Model.Book;
import Library.Model.BookCategory;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author regis
 */
public class BookDb extends ConnectDatabase{
    
    public void createBookTable(){
        
        try {
            connect();
            s = c.createStatement();
            
            String query = "CREATE TABLE IF NOT EXISTS Book("
                    + "book_id varchar(5) PRIMARY KEY NOT NULL,"
                    + "title varchar(40) NOT NULL,"
                    + "publishing_House varchar(40) NOT NULL,"
                    + "date_of_publication varchar(40) NOT NULL,"
                    + "author varchar(50) NOT NULL,"
                    + "pages int NOT NULL,"
                    + "cat_id varchar(50) REFERENCES BookCategory(category_id));";
            s.executeUpdate(query);
            s.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally{
            disconnect();
        }
    }
    public void insertBook(Book book){
        try {
            createBookTable();
            connect();
            PreparedStatement ps = c.prepareStatement("INSERT INTO Book VALUES(?,?,?,?,?,?,?)");
            ps.setString(1, book.getBookId());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getPublishingHouse());
            ps.setString(4, book.getDateOfPublication());
            ps.setString(5, book.getAuthor());
            ps.setInt(6, book.getPages());
            ps.setString(7, book.getBookCategory().getCategoryId());
            
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
    }
    public List allBooks(){
        List<Book> books = new ArrayList<>();
        try {
            connect();
            s = c.createStatement();
            String sql = "SELECT * FROM Book";
            rs = s.executeQuery(sql);
            while(rs.next()){
                
                books.add(new Book(rs.getString(1), rs.getString(2), 
                        rs.getString(3), rs.getString(4), rs.getString(5), rs.getInt(6), new BookCategory(rs.getString(7), "")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
        return books;
    }
    public void updateBook(String id,String name){
        try {
            connect();
            CallableStatement cs = c.prepareCall("{CALL AddBook(?, ?)}");
            cs.setString(1, id);
            cs.setString(2, name);
            cs.execute();
            cs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
    }
}
