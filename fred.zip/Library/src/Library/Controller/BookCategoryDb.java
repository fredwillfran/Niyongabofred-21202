/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Controller;

import Library.Model.BookCategory;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author regis
 */
public class BookCategoryDb extends ConnectDatabase{
    public void createTable1(){
        try {
            connect();
            s = c.createStatement();
            
            String sql = "CREATE TABLE IF NOT EXISTS BookCategory("
                    +"Category_id varchar(50) PRIMARY KEY NOT NULL,"
                    +"category_name varchar(50) NOT NULL);";
            s.executeUpdate(sql);
            s.close();
        } catch (SQLException ex) {
            
        }finally{
            disconnect();
        }
        
    }
    public void insertCategory(BookCategory bc){
        try {
            createTable1();
            connect();
            PreparedStatement ps = c.prepareStatement("INSERT INTO BookCategory VALUES(?,?)");
            ps.setString(1, bc.getCategoryId());
            ps.setString(2, bc.getCategoryName());
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
    }
    public List allCategories(){
        List<BookCategory> categories = new ArrayList<>();
        try {
            connect();
            s = c.createStatement();
            String sql = "SELECT * FROM BookCategory";
            rs = s.executeQuery(sql);
            while(rs.next()){
                categories.add(new BookCategory(rs.getString(1), rs.getString(2)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            disconnect();
        }
        return categories;
    }
}
