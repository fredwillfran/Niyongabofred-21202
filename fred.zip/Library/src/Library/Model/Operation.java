/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Model;

/**
 *
 * @author regis
 */
public class Operation {
    private String firstname;
    private String bookname;
    private String date;
    private String status;

    public Operation() {
    }
    
    

    public Operation(String firstname, String bookname, String date, String status) {
        this.firstname = firstname;
        this.bookname = bookname;
        this.date = date;
        this.status = status;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getBookname() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname = bookname;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
