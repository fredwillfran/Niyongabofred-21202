/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Library.Model;

import java.time.LocalDateTime;

/**
 *
 * @author regis
 */
public class CheckInOutC {
    private LocalDateTime dateTime;
    private String status;
    private OperationCategory operationCategory;

    public CheckInOutC(LocalDateTime dateTime, String status, OperationCategory operationCategory) {
        this.dateTime = dateTime;
        this.status = status;
        this.operationCategory = operationCategory;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OperationCategory getOperationCategory() {
        return operationCategory;
    }

    public void setOperationCategory(OperationCategory operationCategory) {
        this.operationCategory = operationCategory;
    }
    
    
}
